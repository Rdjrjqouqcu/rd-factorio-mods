--
-- PYANODONS COMPAT SPENT FUEL
--

if mods["pycoalprocessing"] then
  data.raw["item"]["fuelmix-solid"].burnt_result = ""
end
