


local enable_waterbox_feature = settings.startup["rd-enable-waterbox"].value
waterbox_module = require("waterbox/control.lua")
if enable_waterbox_feature then
	script.on_event(defines.events.on_entity_died, waterbox_module[1], {{filter="name", name = "waterbox"}})
	script.on_nth_tick(10, waterbox_module[2])
end

local enable_biter_se_feature = settings.startup["rd-enable-biter-se"].value
biter_se_module = require("biterSE/control.lua")
if enable_biter_se_feature then
	if script.active_mods["space-exploration"] then
		biter_se_module[1]()
	else
		-- settings.startup["rd-enable-biter-se"].value = false
		error("space exploration not active, reset settings or enable space exploration")
	end
end

local enable_pesticide_feature = settings.startup["rd-enable-pesticide"].value
-- pesticide_module = require("pesticide/control.lua")
if enable_pesticide_feature then
	error("pesticide not yet ready")
end

local function rd_on_init()
	global.rd_tweaks = {}
	if enable_biter_se_feature then
		biter_se_module[2]()
	end
	if enable_waterbox_feature then
		waterbox_module[3]()
	end
end
script.on_init(rd_on_init)