local entity = table.deepcopy(data.raw["container"]["wooden-chest"])
local item = table.deepcopy(data.raw["item"]["wooden-chest"])
local recipe = {
	type = "recipe",
	name = "waterbox",
	energy_required = 4,
	enabled = "false",
	category = "crafting",
	subgroup = "terrain",
	order = "z",
	ingredients =
	{
		{"explosives", 10},
		{"wooden-chest", 1},
		{"grenade", 1},
	},
	result = "waterbox"
}
local research = {
  type = "technology",
  name = "waterboxes",
  icon = "__rd-tweaks__/waterbox/graphics/waterbox-technology.png",
  icon_size = 100,
  prerequisites = {"landfill", "explosives", "military-2"},
  unit = {
    count = 200,
    ingredients =
    {
      {"automation-science-pack", 1},
      {"logistic-science-pack", 1},
    },
    time = 25
  },
  effects = {
    {
      type = "unlock-recipe",
      recipe = "waterbox"
    }
  },
  order = "b-d"
}

entity.name = "waterbox"
entity.alert_when_damaged = false
entity.corpse = nil
entity.create_ghost_on_death = false
entity.max_health = 10
entity.minable.result = "waterbox"
entity.fast_replaceable_group = nil
entity.inventory_size = 0
entity.picture.layers[1].filename = "__rd-tweaks__/waterbox/graphics/waterbox.png"
entity.picture.layers[1].hr_version.filename = "__rd-tweaks__/waterbox/graphics/hr-waterbox.png"
entity.icon = "__rd-tweaks__/waterbox/graphics/waterbox_icon.png"
entity.icon_size = 40

item.name = "waterbox"
item.place_result = "waterbox"
item.stack_size = 50
item.icon = "__rd-tweaks__/waterbox/graphics/waterbox_icon.png"
item.icon_size = 40

local separate_research = settings.startup["rd-waterbox-separate-research"].value

if separate_research then
    return {entity, item, recipe, research}
else
    table.insert(data.raw["technology"]["cliff-explosives"].effects, {type = "unlock-recipe",recipe = "waterbox"})
    return {entity, item, recipe}
end
