
local fluid = {
    type = "fluid",
    name = "fuel-mix",
    icon = "__base__/graphics/icons/fluid/crude-oil.png",
    icon_size = 64,
    icon_mipmaps = 4,
    default_temperature = 15, -- less than 15 = liquid / equal a 15 = gas
    base_color = {r = 0.937, g = 0.611, b = 0.00},
    flow_color = {r = 0.937, g = 0.611, b = 0.00},
    max_temperature = 15,
    gas_temperature = 20,
	fuel_value = "1MJ"
}

--local entity = {
--	name = "fuel-mixer",
--	type = "assembling-machine",
--	icon = "__gas-boiler__/graphics/icons/gas-boiler.png",
--	icon_size = 32
--}

local entity = util.table.deepcopy(data.raw.boiler.boiler)
entity.name = "fuel-mixer"
entity.icon = "__gas-boiler__/graphics/icons/gas-boiler.png"
entity.icon_size = 32
entity.minable.result = "fuel-mixer"
entity.fast_replaceable_group = nil
entity.next_upgrade = nil
entity.energy_usage = "1MJ"
entity.energy_source = {
	type = "fluid",
	fluid_box = {
		base_area = 1,
		height = 1,
		base_level = -1,
		pipe_covers = pipecoverspictures(),
		pipe_picture = {
			north = {
				filename = "__gas-boiler__/graphics/entity/"
					.."assembling-machine-1-pipe-N.png",
				priority = "extra-high",
				width = 35,
				height = 18,
				shift = util.by_pixel(2.5, 14),
				hr_version = {
					filename = "__gas-boiler__/graphics/entity/"
						.."hr-assembling-machine-1-pipe-N.png",
					priority = "extra-high",
					width = 71,
					height = 38,
					shift = util.by_pixel(2.25, 13.5),
					scale = 0.5
				}
			},
			east = {
				filename = "__gas-boiler__/graphics/entity/"
					.."assembling-machine-1-pipe-E.png",
				priority = "extra-high",
				width = 20,
				height = 38,
				shift = util.by_pixel(-25, 1),
				hr_version = {
					filename = "__gas-boiler__/graphics/entity/"
						.."hr-assembling-machine-1-pipe-E.png",
					priority = "extra-high",
					width = 42,
					height = 76,
					shift = util.by_pixel(-24.5, 1),
					scale = 0.5
				}
			},
			south = {
				filename = "__gas-boiler__/graphics/entity/"
					.."assembling-machine-1-pipe-S.png",
				priority = "extra-high",
				width = 44,
				height = 31,
				shift = util.by_pixel(0, -31.5),
				hr_version = {
					filename = "__gas-boiler__/graphics/entity/"
						.."hr-assembling-machine-1-pipe-S.png",
					priority = "extra-high",
					width = 88,
					height = 61,
					shift = util.by_pixel(0, -31.25),
					scale = 0.5
				}
			},
			west = {
				filename = "__gas-boiler__/graphics/entity/"
					.."assembling-machine-1-pipe-W.png",
				priority = "extra-high",
				width = 19,
				height = 37,
				shift = util.by_pixel(25.5, 1.5),
				hr_version = {
					filename = "__gas-boiler__/graphics/entity/"
						.."hr-assembling-machine-1-pipe-W.png",
					priority = "extra-high",
					width = 39,
					height = 73,
					shift = util.by_pixel(25.75, 1.25),
					scale = 0.5
				}
			}
		},
		pipe_connections = {
			{type = "input", position = {0, 1.5}},
		},
		secondary_draw_orders = {
			south = 32,
			north = -1,
			east = -1,
			west = -1,
		}
	},
	burns_fluid = true,
	scale_fluid_usage = true,
	emissions_per_minute = 30,
	smoke = {{
			name = "smoke",
			north_position = util.by_pixel(-38, -47.5),
			south_position = util.by_pixel(38.5, -32),
			east_position = util.by_pixel(20, -70),
			west_position = util.by_pixel(-19, -8.5),
			frequency = 15,
			starting_vertical_speed = 0.3,
			starting_frame_deviation = 0
	}},
	light_flicker = {
		color = colors.gas_fire_glow,
		minimum_light_size = 0.1,
		light_intensity_to_size_coefficient = 1
	}
}

local item = util.table.deepcopy(data.raw.item.boiler)
item.name = "fuel-mixer"
item.icon = "__base__/graphics/icons/pump.png"
item.icon_size = 64
item.icon_mipmaps = 4
item.place_result = "fuel-mixer"

local mix_recipe = {
	type = "recipe",
	name = "fuel-mixer",
	energy_required = 1,
	category = "chemistry",
	enabled = "true",
	hidden = "true",
	hide_from_player_crafting = "true",
	ingredients = {},
	results = {{type="fluid", name="fuel-mix", amount=50}}
}

local recipe = {
	type = "recipe",
	name = "fuel-mixer",
	energy_required = 1,
	enabled = "false",
	ingredients =
	{
		{"pump",1},
	},
	result = "fuel-mixer"
}

local dev_recipe = {
	type = "recipe",
	name = "dev-fuel-mixer",
	energy_required = 0.1,
	enabled = "true",
	ingredients =
	{
		{"wood", 1},
	},
	result = "fuel-mixer"
}

--table.insert(
--  data.raw["technology"]["fluid-handling"].effects,
--  {type = "unlock-recipe",recipe = "fuel-mixer"})

return {fluid, item, entity, recipe, mix_recipe, dev_recipe}