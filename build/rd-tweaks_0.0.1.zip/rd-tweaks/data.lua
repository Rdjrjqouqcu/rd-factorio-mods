


local enable_waterbox_feature = settings.startup["rd-enable-waterbox"].value
waterbox_module = require("waterbox/data.lua")
if enable_waterbox_feature then
	data:extend(waterbox_module)
end

local enable_biter_se_feature = settings.startup["rd-enable-biter-se"].value
-- waterbox_module = require("waterbox/data.lua")
if enable_biter_se_feature then
	-- pass no data stage for module
end

local enable_pesticide_feature = settings.startup["rd-enable-pesticide"].value
-- pesticide_module = require("pesticide/data.lua")
if enable_pesticide_feature then
	error("pesticide not yet ready")
	-- data:extend(pesticide_module)
end

local enable_fuelmix_feature = settings.startup["rd-enable-fuel-mix"].value
-- fuelmix_module = require("fuel_mix/data.lua")
if enable_fuelmix_feature then
	error("fuel_mix not yet ready")
	-- data:extend(fuelmix_module)
end
