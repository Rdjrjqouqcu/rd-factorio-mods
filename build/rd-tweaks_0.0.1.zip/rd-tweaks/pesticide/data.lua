
local projectile = {
  type = "projectile",
  name = "pesticide",
  flags = {"not-on-map"},
  acceleration = 0.005,
  action =
  {
    type = "direct",
    action_delivery =
    {
      type = "instant",
      target_effects =
      {
        type = "create-entity",
        show_in_tooltip = true,
        entity_name = "tree-01",
        offsets = {{-0.7, -0.7},{-0.7, 0.7},{0.7, -0.7},{0.7, 0.7},{0, 0}},
        offset_deviation = {{-0.4, -0.4}, {0.4, 0.4}},
      }
    }
  },
  light = {intensity = 0.5, size = 4},
  smoke =
  {
    {
      name = "poison-capsule-smoke",
      deviation = {0.15, 0.15},
      frequency = 1,
      position = {0, 0},
      starting_frame = 3,
      starting_frame_deviation = 5,
      starting_frame_speed_deviation = 5
    }
  }
}

local item = {
  type = "capsule",
  name = "pesticide",
  icon = "__base__/graphics/icons/grenade.png",
  icon_size = 64, icon_mipmaps = 4,
  capsule_action =
  {
    type = "throw",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "capsule",
      cooldown = 15,
      projectile_creation_distance = 0.6,
      range = 25,
      ammo_type =
      {
        category = "capsule",
        target_type = "position",
        action =
        {
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "pesticide",
              starting_speed = 0.3
            }
          }
        }
      }
    }
  },
  subgroup = "capsule",
  order = "a[pesticide]",
  stack_size = 100
}

local recipe = {
	type = "recipe",
	name = "pesticide",
	energy_required = 1,
	enabled = "false",
	category = "crafting",
	subgroup = "terrain",
	order = "z",
	ingredients =
	{
		{"sulfur", 1},
		{"water-barrel", 1},
	},
	result = "pesticide"
}

local research = {
    type = "technology",
    name = "pesticide",
    icon = "__rd-tweaks__/waterbox/graphics/waterbox-technology.png",
    icon_size = 100,
	prerequisites = {"sulfur-processing"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"automation-science-pack", 1},
      },
      time = 25
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pesticide"
      }
    },
    order = "b-d"
 }
 
local dev_recipe = {
	type = "recipe",
	name = "dev_pesticide",
	energy_required = 1,
	enabled = "true",
	category = "crafting",
	subgroup = "terrain",
	order = "z",
	ingredients =
	{
		{"wood", 1},
	},
	result = "pesticide"
}


return {projectile, item, recipe, dev_recipe, research}