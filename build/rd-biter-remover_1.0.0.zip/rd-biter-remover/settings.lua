data:extend({
	{
		type = "bool-setting",
		name = "rd-biter-combine-research",
		setting_type = "startup",
		default_value = false,
		order = "a-a",
	},

})
