
data.raw["gui-style"]["default"]["rd_se_table_style"] = {
  -- table_style
  horizontal_line_color= {1,1,1,1},
  vertical_line_color= {1,1,1,1},
  -- gui-style
  type="table_style",
}
