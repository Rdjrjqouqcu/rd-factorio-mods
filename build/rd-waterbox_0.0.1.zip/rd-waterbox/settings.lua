data:extend({
	{
		type = "bool-setting",
		name = "rd-waterbox-separate-research",
		setting_type = "startup",
		default_value = true,
		order = "a",
	},
	{
		type = "bool-setting",
		name = "rd-waterbox-iron-chest",
		setting_type = "startup",
		default_value = false,
		order = "b",
	},
})