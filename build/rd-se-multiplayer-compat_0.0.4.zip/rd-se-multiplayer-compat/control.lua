local LOBBY_RADIUS = 42
local LOBBY_WATER_GAP = 10
local LOBBY_LOCATION = {x=0,y=0}
local LOBBY_AREA = {
    left_top = { x = LOBBY_LOCATION["x"] - LOBBY_RADIUS, y = LOBBY_LOCATION["y"] - LOBBY_RADIUS},
    right_bottom = { x = LOBBY_LOCATION["x"] + LOBBY_RADIUS, y = LOBBY_LOCATION["y"] + LOBBY_RADIUS},
}

local ADMIN_DEBUG = settings.startup["rd-sem-admin-debug"].value
local REQUIRE_PERMS = settings.startup["rd-sem-require-perms"].value
local CRASHSITE_ITEMS = settings.startup["rd-sem-crashsite-items"].value
local WORM_KILL_RATE = settings.startup["rd-sem-worm-kill"].value


local function starts_with(base, search)
    return string.sub(base,1,string.len(search))==search
end

local function get_remainder(base, search)
    return string.sub(base, 1 + string.len(search))
end

local function announce(msg)
    for _, player in pairs(game.players) do
        player.print(msg)
    end
end

local function admin_announce(msg)
    for _, player in pairs(game.players) do
        if player.admin and ADMIN_DEBUG then
            player.print("[A]: "..msg)
        end
    end
end

local function isFactionActive(faction)
    if type(faction) == "string" then
        faction = game.forces[faction]
    end
    local active = false
    for _,player in pairs(game.players) do
        if player.force.name == faction.name then
            active = active or player.connected
        end
    end
    -- return global.rd_sem.debug
    return active
end

local function tableLength(table)
    local count = 0
    for _ in pairs(table) do count = count + 1 end
    return count
end

local function generate_lobby()
    if global.rd_sem.lobby_generated then
        return
    end
    admin_announce("generating lobby")
    global.rd_sem.lobby_generated = true
    game.map_settings.enemy_evolution.enabled = false

    local surface = game.surfaces['nauvis']
    surface.always_day=true
    surface.destroy_decoratives(LOBBY_AREA)
    for _,entity in pairs(surface.find_entities_filtered({force='enemy'})) do
        entity.destroy()
    end

    game.forces['player'].set_spawn_position(LOBBY_LOCATION, surface)

    -- create planet enemy forces

	game.create_force("no_evolution")
	local force = game.forces["no_evolution"]
    force.ai_controllable = true 
    force.evolution_factor = 0

	game.create_force("low_evolution")
	local force = game.forces["low_evolution"]
    force.ai_controllable = true 
    force.evolution_factor = 0.25

	game.create_force("medium_evolution")
	local force = game.forces["medium_evolution"]
    force.ai_controllable = true 
    force.evolution_factor = 0.5

	game.create_force("high_evolution")
	local force = game.forces["high_evolution"]
    force.ai_controllable = true 
    force.evolution_factor = 0.75

	game.create_force("max_evolution")
	local force = game.forces["max_evolution"]
	force.ai_controllable = true 
    force.evolution_factor = 1.0

	local force = game.forces["enemy"]
    force.evolution_factor = 1.0

    -- Build starting circle
    local start_tiles = {}
    for i=LOBBY_AREA.left_top.x,LOBBY_AREA.right_bottom.x,1 do
        for j=LOBBY_AREA.left_top.y,LOBBY_AREA.right_bottom.y,1 do

            local dist_origin = (LOBBY_LOCATION.x - i) ^ 2 + (LOBBY_LOCATION.y - j) ^ 2

            if (dist_origin <= (LOBBY_RADIUS - LOBBY_WATER_GAP) ^ 2) then
                table.insert(start_tiles, {name = 'tutorial-grid', position ={i,j}})
            end
            if ((LOBBY_RADIUS - LOBBY_WATER_GAP) ^ 2 < dist_origin and dist_origin  < LOBBY_RADIUS ^ 2) then
                table.insert(start_tiles, {name = 'out-of-map', position ={i,j}})
            end
        end
    end
    surface.set_tiles(start_tiles)

    -- clean starting circle
    for key, entity in pairs(surface.find_entities_filtered({area=LOBBY_AREA})) do
        if entity.valid and entity and entity.position then
            if ((LOBBY_LOCATION.x - entity.position.x)^2 + (LOBBY_LOCATION.y - entity.position.y)^2 < LOBBY_RADIUS^2) then
                if entity.type == "character" then
                    -- skip characters
                else
                    entity.destroy()
                end
            end
        end
    end
    admin_announce("lobby generated")
end

local function formattime_hours_mins(ticks)
    local seconds = ticks / 60
    local minutes = math.floor((seconds)/60)
    local hours   = math.floor((minutes)/60)
    local minutes = math.floor(minutes - 60*hours)
    return string.format("%dh:%02dm", hours, minutes)
end

local function tickPlayerList(uiplayer)
	local daytime = game.surfaces.nauvis.daytime
	local container = uiplayer.gui.top.rd_container
	-- updating day time progress
	local player_list = container.player_list

	if(player_list == nil) then return end

	local online_list = player_list.online_list
    local offline_list = player_list.offline_list
	online_list.clear()
	offline_list.clear()

	for _,player in pairs(game.players) do
		local name = player.name
		local forcename = player.force.name
		local enemy_force = game.forces['enemy='..forcename]
        local difficulty = 'none'
        local difficulty_breakdown = ''
		local time = formattime_hours_mins(player.online_time)
		if(enemy_force ~= nil) then
			local diff = enemy_force.evolution_factor * 100
            difficulty = string.format("%.f", diff)
            difficulty_breakdown = string.format("%.f,%.f,%.f", 
                        enemy_force.evolution_factor_by_time * 10000,
                        enemy_force.evolution_factor_by_pollution * 10000,
                        enemy_force.evolution_factor_by_killing_spawners * 10000
                    )
        end
        local capt = "missing"
        if ADMIN_DEBUG and uiplayer.admin then
            capt = "["..forcename.."] "..name.." | Evolution "..difficulty.."% ("..difficulty_breakdown..")| "..time
        else
            capt = "["..forcename.."] "..name.." | Evolution "..difficulty.."%| "..time
        end
		
        if(player.connected) then
            local info = online_list.add{type="flow", name=player.name.."_infos",direction="horizontal"}
            info.style['padding'] = 0
			local label = info.add{name=(player.name.."_info"),type="label", caption=capt}
            local c = player.color
            label.style['font_color'] = {r=c.r,g=c.g,b=c.b,a=1}
            label.style['font'] = "default-semibold"

            if REQUIRE_PERMS and uiplayer.admin then
                local founder = info.add{
                    name=("founder="..player.name),
                    type="checkbox",
                    caption="founder",
                    state=global.rd_sem.player_settings[player.name]["can_create_empire"]
                }
            end

		else
            local info = offline_list.add{type="flow", name=player.name.."_infos",direction="horizontal"}
            info.style['padding'] = 0
            local label = info.add{name=(player.name.."_info"),type="label", caption=capt}
            label.style['font_color'] = {r=0.5,g=0.5,b=0.5}
            local last_seen_str = formattime_hours_mins(game.tick - player.last_online).." ago"
            local last_seen = info.add{name=(player.name.."_last_seen"),type="label", caption=last_seen_str}
		end
	end
end

local function createPlayerList(player)
	local container = player.gui.top.rd_container
	local player_list = container.add{type="flow", name="player_list", direction="vertical"}
	local online_list = player_list.add{type="frame", name="online_list",direction="vertical"}
	local offline_list = player_list.add{type="frame", name="offline_list",direction="vertical"}

    player_list.style["horizontally_stretchable"]=true
    online_list.style["horizontally_stretchable"]=true
    offline_list.style["horizontally_stretchable"]=true

	tickPlayerList(player)
end

local function togglePlayerList(player)
	if(player.gui.top.rd_container.player_list == nil) then
		createPlayerList(player)
	else
		player.gui.top.rd_container.player_list.destroy()
	end
end

local function showSpawnGui(player)
	if(player.gui.center.spawn_gui ~= nil) then
		player.gui.center.spawn_gui.destroy()
	end
	local widget = player.gui.center.add({type="frame",direction="vertical",name="spawn_gui"})
	widget.add({type="label",caption="Welcome new person"})
	widget.add({type="label",caption=" "})
	widget.add({type="label",caption="You can spawn alone"})
	widget.add({type="button",name="spawn_alone",caption="Create a new spawn"})
	widget.add({type="label",caption=" "})
	local widgetInner = widget.add({type="frame",direction="horizontal"})
	widgetInner.add({type="label",caption="or ask someone to join their Factory"})
	widgetInner.add({type="label",caption=" "})
	for _,p in pairs(game.connected_players) do
		if(p.force.name ~= 'player') then
			widgetInner.add({type="button",name=("join="..(p.name)),caption=("team up with "..(p.name))})
		end
	end
end

local function createContainer(player)
	if(player.gui.top.rd_container == nil) then
		local container = player.gui.top.add{name="rd_container",type="frame", direction="vertical"}
        container.style["top_margin"]=10
        container.style["padding"]=2

		local button_menu = container.add{name="button_menu",type="flow",direction="horizontal"}
        button_menu.style["padding"]=0
        button_menu.style["vertical_align"]="center"

        local toggle_list = button_menu.add{name="toggle_players",type="button", caption="Players"}
        toggle_list.style["padding"]=0
        
        local toggle_list = button_menu.add{name="toggle_spawn_gui",type="button", caption="Start"}
        toggle_list.style["padding"]=0
        
        if not player.force.name == "player" then
            player.gui.top.rd_container.button_menu.toggle_spawn_gui.visible = false
        end

        if ADMIN_DEBUG and player.admin then
            local debug = button_menu.add{name="debug",type="button", caption="Debug"}
            debug.style["padding"]=0
        end
	end
end

local function on_create_player(event)
    generate_lobby()
    local player = game.players[event.player_index]
    global.rd_sem.player_settings[player.name] = {
        can_create_empire = false
    }
	player.teleport(LOBBY_LOCATION, game.surfaces['nauvis'])
    announce((player.name).." just spawned!")
    createContainer(player)
    togglePlayerList(player)
end

local function on_chunk_gen(e)
    local surface = e.surface
    if surface.name == "nauvis" then
        for _,entity in pairs(surface.find_entities_filtered({force='enemy',area=e.area})) do
            entity.destroy()
        end
        return
    elseif global.rd_sem.surface_enemy_force[surface.name] == nil then
        local forces = {
            "no_evolution",
            "low_evolution",
            "medium_evolution",
            "high_evolution",
            "max_evolution",
        }
        global.rd_sem.surface_enemy_force[surface.name] = forces[math.floor(math.random() * 5) + 1]
        admin_announce("assigned "..global.rd_sem.surface_enemy_force[surface.name].." to "..surface.name)
    end
    for _,entity in pairs(surface.find_entities_filtered({force='enemy',area=e.area})) do
        entity.force = global.rd_sem.surface_enemy_force[surface.name]
    end
end

local function askToJoin(player, playerAsking)
	local widget = player.gui.center.add({type="frame",direction="vertical",name="askToJoin"})
	widget.add({type="label",caption=((playerAsking.name.." wants to join you"))})
	local widgetInner = widget.add({type="frame",direction="horizontal"})
	widgetInner.add({type="button",caption="accept",name=("acceptJoinRequest="..(playerAsking.name))})
	widgetInner.add({type="button",caption="refuse",name=("refuseJoinRequest="..(playerAsking.name))})
end

local function addPlayerToEmpire(player, playerForce)
    announce(player.name.." joined team "..playerForce.name)
    player.force = playerForce
    local playerSurface = "nauvis"
    for surface,force in pairs(global.rd_sem.surface_enemy_force) do
        if force == ("enemy="..playerForce.name) then
            playerSurface = surface
        end
    end
    player.teleport(player.force.get_spawn_position(playerSurface), playerSurface)
end

local function createPlayerEmpire(player)
    if player.force.name ~= "player" then
        admin_announce("empire already created")
        return true
    end
    if REQUIRE_PERMS and not global.rd_sem.player_settings[player.name]["can_create_empire"] then
        player.print("You do not yet have permissions to found an empire")
        return false
    end
    if tableLength(game.forces) > 62 then
        announce("there can't be more than 30 players due to the factorio force amount limitation! "..player.name.." has to join a team")
        return false
    end
    announce((player.name).." just created a new Empire! expect some lag")
    remote.call("space-exploration", "setup_multiplayer_test", { force_name = player.name, players = {player}, match_nauvis_seed = false})
    global.rd_sem.player_forces[player.name] = player.force.name
    local new_surface = player.surface
    if new_surface.name == "Nauvis" then
        admin_announce("unknown issue, aborting")
        return false
    end
	local enemy_force = ('enemy='..(player.name))
	game.create_force(enemy_force)
	local force = game.forces[enemy_force]
	force.ai_controllable = true 
    
    global.rd_sem.surface_enemy_force[new_surface.name] = enemy_force
    admin_announce("assigned "..global.rd_sem.surface_enemy_force[new_surface.name].." to "..new_surface.name)
    
    local change_forces = {
        "no_evolution",
        "low_evolution",
        "medium_evolution",
        "high_evolution",
        "max_evolution",
        "enemy",
    }
    for _,tmp_force in pairs(change_forces) do 
        for _,entity in pairs(new_surface.find_entities_filtered({force=tmp_force})) do
            entity.force = enemy_force
        end
    end

    player.force.chart(new_surface, {{x = -256, y = -256}, {x = 256, y = 256}})

    if CRASHSITE_ITEMS then
        if script.active_mods["Krastorio2"] then
            -- usually spawns placed
            player.insert{name="kr-crash-site-assembling-machine-1-repaired", count=2}
            player.insert{name="kr-crash-site-assembling-machine-2-repaired", count=2}
            player.insert{name="kr-crash-site-generator", count=1}
            player.insert{name="kr-crash-site-lab-repaired", count=1}
            -- from containers
            player.insert{name="kr-shelter", count=1}
            player.insert{name="medium-electric-pole", count=10}
            player.insert{name="iron-plate", count=100}
            player.insert{name="copper-cable", count=50}
            player.insert{name="iron-gear-wheel", count=50}
            player.insert{name="electronic-circuit", count=200}
            -- breaking down the rest of the debris
            player.insert{name="iron-plate", count=200}
            player.insert{name="copper-cable", count=200}
            player.insert{name="iron-gear-wheel", count=25}
            player.insert{name="kr-sentinel", count=4}
            -- top up spawning in inv
            player.insert{name="wood", count=99}
            player.insert{name="fuel", count=600}
            player.insert{name="se-medpack", count=5}
        else 
            player.insert{name="automation-science-pack", count=10}
            player.insert{name="iron-plate", count=100}
            player.insert{name="wood", count=10}
            player.insert{name="stone-furnace", count=1}
            player.insert{name="burner-mining-drill", count=1}
            player.insert{name="se-medpack", count=10}
        end
    end

    return true
end

local function updateEvolution(playerForce)
    local biter_nest_kill = 0
    local spitter_nest_kill = 0
    if playerForce.kill_count_statistics ~= nil then
        biter_nest_kill = playerForce.kill_count_statistics.get_flow_count{name="biter-spawner", input="input_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
        spitter_nest_kill = playerForce.kill_count_statistics.get_flow_count{name="spitter-spawner", input="input_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
    end
    local behemoth_worm_turret_kill = 0
    local big_worm_turret_kill = 0
    local medium_worm_turret_kill = 0
    local small_worm_turret_kill = 0
    if playerForce.entity_build_count_statistics ~= nil then
        behemoth_worm_turret_kill = playerForce.entity_build_count_statistics.get_flow_count{name="behemoth-worm-turret", input="output_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
        big_worm_turret_kill = playerForce.entity_build_count_statistics.get_flow_count{name="big-worm-turret", input="output_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
        medium_worm_turret_kill = playerForce.entity_build_count_statistics.get_flow_count{name="medium-worm-turret", input="output_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
        small_worm_turret_kill = playerForce.entity_build_count_statistics.get_flow_count{name="small-worm-turret", input="output_counts", precision_index = defines.flow_precision_index.one_minute, count=true}
    end

    local enemy = game.forces[('enemy='..(playerForce.name))]
    local worm_kills = behemoth_worm_turret_kill + big_worm_turret_kill + medium_worm_turret_kill + small_worm_turret_kill
    local nest_kills = biter_nest_kill + spitter_nest_kill
    local total_kills = nest_kills + worm_kills * WORM_KILL_RATE

    local surface_pollution = 0
    for surface_name,surface_force in pairs(global.rd_sem.surface_enemy_force) do
        if surface_force == enemy.name then
            surface_pollution = game.surfaces[surface_name].get_total_pollution() / 20
            break
        end
    end

    local evo_per_sec = game.map_settings.enemy_evolution.time_factor
    local evo_per_kill = game.map_settings.enemy_evolution.destroy_factor
    local evo_per_pollution = game.map_settings.enemy_evolution.pollution_factor
    
    if isFactionActive(playerForce) then
        enemy.evolution_factor_by_time = enemy.evolution_factor_by_time + 60*evo_per_sec
        enemy.evolution_factor_by_pollution = enemy.evolution_factor_by_pollution + surface_pollution * evo_per_pollution
    end
    enemy.evolution_factor_by_killing_spawners = enemy.evolution_factor_by_killing_spawners + (evo_per_kill * total_kills)

    enemy.evolution_factor = 1 - (1 - enemy.evolution_factor_by_time) * (1 - enemy.evolution_factor_by_pollution) * (1 - enemy.evolution_factor_by_killing_spawners)
end

local function protectForce(playerForce)
    if type(playerForce) == "string" then
        playerForce = game.forces[playerForce]
    end
    if playerForce.name == "player" then
        return
    end
    local protect = not isFactionActive(playerForce)
    local surface = "nauvis"
    for surf, force in pairs(global.rd_sem.surface_enemy_force) do
        if get_remainder(force, "enemy=") then
            surface = game.surfaces[surf]
            break
        end
    end
    if protect then
        admin_announce("protection for "..playerForce.name.." set to True on "..surface.name)
    else
        admin_announce("protection for "..playerForce.name.." set to False on "..surface.name)
    end
	for _,build in pairs(surface.find_entities_filtered{force=playerForce.name}) do
		build.destructible = protect
    end
    local enemy_force = game.forces["enemy="..playerForce.name]
    enemy_force.set_cease_fire(playerForce, protect)
end

local function preventOfflineActivity(event)
    if event and event.group and event.group.valid then
        local force = event.group.force
        if starts_with(force.name, "enemy=") then
            if not isFactionActive(get_remainder(force.name, "enemy=")) then
                event.group.destroy()
            end
        end
    end
end

local function on_init()
    
	global.rd_sem = {}
	global.rd_sem.surface_enemy_force = {}
    global.rd_sem.debug = false
    global.rd_sem.player_forces = {}
    global.rd_sem.player_settings = {}
    global.rd_sem.player_settings = {}
    
    remote.call("freeplay", "set_disable_crashsite", true)
    remote.call("freeplay", "set_skip_intro", true)

    if script.active_mods["Krastorio2"] then
        remote.call("kr-crash-site", "crash_site_enabled", false)
    end

    remote.add_interface("rd-sem", { allow_aai_crash_sequence = function(data) return {allow = false, weight = 1} end})
    -- remote.add_interface("rd-tweaks", { allow_aai_crash_sequence = function(data) return {allow = false, weight = 1} end})

end

local function init()
    script.on_init(on_init)

    script.on_event(defines.events.on_player_created, on_create_player)
    script.on_event(defines.events.on_chunk_generated, on_chunk_gen)
    script.on_event(defines.events.on_unit_group_finished_gathering, preventOfflineActivity)

    script.on_nth_tick(60*10, function(e)
        if e.tick % (60*10*6) == 0 then
            for _,force in pairs(global.rd_sem.player_forces) do
                updateEvolution(game.forces[force])
            end
        end
        for _,player in pairs(game.connected_players) do
            tickPlayerList(player)
        end
    end)

    script.on_event(defines.events.on_gui_checked_state_changed, function(event)
        if not (event and event.element and event.element.valid) then return end
        local player = game.players[event.player_index]
        local element = event.element
        if starts_with(element.name,"founder=") then
            local target_player = game.players[get_remainder(element.name,"founder=")]
            global.rd_sem.player_settings[target_player.name]["can_create_empire"] = element.state
            if element.state then
                admin_announce("set "..target_player.name.." founder state to true")
            else
                admin_announce("set "..target_player.name.." founder state to false")
            end
        end
    end)

    script.on_event(defines.events.on_gui_click, function(event)
        if not (event and event.element and event.element.valid) then return end
        local player = game.players[event.player_index]
        if event.element.name == 'toggle_players' then
            togglePlayerList(player)
        elseif event.element.name == 'toggle_spawn_gui' then
            if(player.gui.center.spawn_gui ~= nil) then
                player.gui.center.spawn_gui.destroy()
            else
                showSpawnGui(player)
            end
        elseif event.element.name == 'spawn_alone' then
            local created = createPlayerEmpire(player)
            if(created) then
                player.gui.center.spawn_gui.destroy()
                player.gui.top.rd_container.button_menu.toggle_spawn_gui.visible = false
            end
        elseif string.sub(event.element.name,1,string.len("join="))=="join=" then
            -- request to join
            local host_player = game.players[string.sub(event.element.name, 1 + string.len("join="))]
			if(host_player ~= nil and host_player.connected) then
				admin_announce((player.name).." wants to join team "..(host_player.force.name))
				askToJoin(host_player, player)
				player.gui.center.spawn_gui.destroy()
			else
				player.print((host_player.name).." is offline")
            end
        elseif string.sub(event.element.name,1,string.len("acceptJoinRequest="))=="acceptJoinRequest=" then
			local playerJoining = game.players[string.sub(event.element.name,1 + string.len("refuseJoinRequest="))]
			player.gui.center.askToJoin.destroy()
			if(playerJoining.connected) then
				playerJoining.print((player.name).." allowed you to join")
            end
            addPlayerToEmpire(playerJoining, player.force)
        elseif string.sub(event.element.name,1,string.len("refuseJoinRequest="))=="refuseJoinRequest=" then
			local playerJoining = game.players[string.sub(event.element.name,1 + string.len("refuseJoinRequest="))]
			player.gui.center.askToJoin.destroy()
			if(playerJoining.connected) then
				playerJoining.print((player.name).." refused to let you join")
				showSpawnGui(playerJoining)
			end
        elseif(event.element.name == 'debug') then
            if player.admin then
                global.rd_sem.debug = not global.rd_sem.debug
                if global.rd_sem.debug then
                    admin_announce("global debug now true")
                else
                    admin_announce("global debug now false")
                end
                -- protectForce(player.force)
                -- admin_announce("current tick: "..game.tick)
                -- admin_announce("====players====")
                -- for _,player in pairs(game.players) do
                --     if player.connected then
                --         admin_announce(player.name..": "..player.force.name.." - ONLINE")
                --     else
                --         admin_announce(player.name..": "..player.force.name.." - OFFLINE last seen: "..player.last_online)
                --     end
                -- end
                -- admin_announce("====forces====")
                -- for _,force in pairs(game.forces) do
                --     admin_announce(force.name)
                -- end
            end
        else
            -- admin_announce(event.element.name)
        end
    end)
end

init()

